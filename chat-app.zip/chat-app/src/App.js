import React from 'react';
import ChatRoom from './component/ChatRoom';

 const App =()=>{
  return(
    <ChatRoom />

  )
 }

export default App;
